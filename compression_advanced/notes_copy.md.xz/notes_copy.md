# My notes
